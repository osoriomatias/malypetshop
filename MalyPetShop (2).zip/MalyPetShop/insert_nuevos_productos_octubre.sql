-- ====================================================================
-- INSERCIÓN MASIVA DE 38 PRODUCTOS NUEVOS (OCTUBRE 2026) EN SUPABASE
-- ====================================================================

-- 1. Insertar o actualizar Productos (IDs 145 al 182)
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (145, 2, 1, 'Royal Canin Feline Kitten (Gatitos)', 'royal-canin-feline-kitten', 'Nutrición a medida para gatitos de 4 a 12 meses. Con defensas naturales reforzadas y alta digestibilidad.', 'gato', 'cachorro', 'todas', 'Cachorro', 'https://http2.mlstatic.com/D_NQ_NP_672535-MLA71077755104_082023-O.webp', TRUE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (146, 2, 1, 'Royal Canin Feline Urinary Care', 'royal-canin-feline-urinary-care', 'Fórmula nutricional precisa que ayuda a mantener el equilibrio saludable de minerales en la orina de gatos adultos sanos.', 'gato', 'adulto', 'todas', 'Cuidado Urinario', 'https://http2.mlstatic.com/D_NQ_NP_649646-MLA71391763715_082023-O.webp', TRUE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (147, 1, 1, 'Royal Canin Giant Adulto', 'royal-canin-giant-adulto', 'Para perros adultos de razas gigantes (> 45 kg) a partir de los 18/24 meses. Soporte articular y cardíaco de alta demanda.', 'perro', 'adulto', 'grande', 'Raza Gigante', 'https://http2.mlstatic.com/D_NQ_NP_806509-MLA46675043685_072021-O.webp', FALSE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (148, 1, 1, 'Royal Canin Giant Junior / Puppy', 'royal-canin-giant-junior-puppy', 'Fase de consolidación muscular y desarrollo esquelético en cachorros de razas gigantes hasta los 18/24 meses de edad.', 'perro', 'cachorro', 'grande', 'Raza Gigante', 'https://http2.mlstatic.com/D_NQ_NP_603837-MLA46675043694_072021-O.webp', FALSE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (149, 5, 1, 'Royal Canin Veterinary Canine Satiety (Obesity)', 'royal-canin-vet-canine-satiety', 'Alimento dietético para perros formulado para reducir el sobrepeso con efecto saciante probado y alto contenido de fibra.', 'perro', 'veterinario', 'todas', 'Veterinario', 'https://http2.mlstatic.com/D_NQ_NP_637254-MLA48098314164_112021-O.webp', FALSE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (150, 5, 1, 'Royal Canin Veterinary Canine Hepatic', 'royal-canin-vet-canine-hepatic', 'Soporte de la función hepática en caso de insuficiencia hepática crónica en perros. Con nivel adaptado de cobre y proteínas vegetales.', 'perro', 'veterinario', 'todas', 'Veterinario', 'https://http2.mlstatic.com/D_NQ_NP_900609-MLA48098314168_112021-O.webp', FALSE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (151, 5, 1, 'Royal Canin Veterinary Canine Diabetic', 'royal-canin-vet-canine-diabetic', 'Manejo nutricional de la diabetes mellitus en perros adultos con aporte controlado de carbohidratos de absorción lenta.', 'perro', 'veterinario', 'todas', 'Veterinario', 'https://http2.mlstatic.com/D_NQ_NP_981519-MLA48098314170_112021-O.webp', FALSE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (152, 2, 2, 'Pro Plan Cat Kitten (Gatitos)', 'pro-plan-cat-kitten', 'Nutrición avanzada con OptiStart para gatitos de hasta 12 meses. Promueve el desarrollo óptimo del cerebro y la visión con DHA.', 'gato', 'cachorro', 'todas', 'Super Premium', 'https://http2.mlstatic.com/D_NQ_NP_830605-MLA46675043688_072021-O.webp', TRUE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (153, 2, 2, 'Pro Plan Cat Reduce Calorie', 'pro-plan-cat-reduce-calorie', 'Fórmula baja en calorías con alto contenido proteico para ayudar a gatos con sobrepeso a alcanzar un peso corporal saludable.', 'gato', 'light', 'todas', 'Control Peso', 'https://http2.mlstatic.com/D_NQ_NP_913729-MLA99843470895_112025-O.webp', FALSE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (154, 1, 15, 'Excellent Perro Puppy (Cachorros)', 'excellent-perro-puppy', 'Alimento completo con proteínas de alta digestibilidad, calcio y fósforo para un crecimiento óseo y muscular óptimo.', 'perro', 'cachorro', 'todas', 'Cachorro', 'https://http2.mlstatic.com/D_NQ_NP_816176-MLA99341181006_112025-F.jpg', TRUE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (155, 1, 15, 'Excellent Perro Fórmula Mantenimiento Adulto', 'excellent-perro-mantenimiento-adulto', 'Fórmula equilibrada para el mantenimiento diario de perros adultos activos con nutrientes clave e ingredientes nobles.', 'perro', 'adulto', 'todas', 'Económico', 'https://http2.mlstatic.com/D_NQ_NP_816176-MLA99341181006_112025-F.jpg', FALSE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (156, 1, 15, 'Excellent Perro Fórmula Mantenimiento Puppy', 'excellent-perro-mantenimiento-puppy', 'Nutrición confiable y accesible para cachorros en etapa de crecimiento con energía concentrada y excelente palatabilidad.', 'perro', 'cachorro', 'todas', 'Económico', 'https://http2.mlstatic.com/D_NQ_NP_816176-MLA99341181006_112025-F.jpg', FALSE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (157, 2, 15, 'Excellent Cat Urinary', 'excellent-cat-urinary', 'Fórmula especialmente desarrollada para colaborar con el mantenimiento de la salud del tracto urinario inferior en felinos adultos.', 'gato', 'adulto', 'todas', 'Salud Urinaria', 'https://http2.mlstatic.com/D_NQ_NP_907577-MLA46675043690_072021-O.webp', TRUE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (158, 2, 15, 'Excellent Cat Mantenimiento', 'excellent-cat-mantenimiento', 'Nueva fórmula balanceada con proteínas seleccionadas para el mantenimiento integral y vitalidad de gatos adultos.', 'gato', 'adulto', 'todas', 'Nuevo', 'https://http2.mlstatic.com/D_NQ_NP_854583-MLA46675043692_072021-O.webp', FALSE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (159, 2, 15, 'Excellent Cat Sterilized', 'excellent-cat-sterilized', 'Alimento formulado específicamente para las necesidades metabólicas de gatos castrados: control calórico y saciedad.', 'gato', 'castrado', 'todas', 'Nuevo', 'https://http2.mlstatic.com/D_NQ_NP_727189-MLA46675043693_072021-O.webp', TRUE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (160, 2, 15, 'Excellent Cat Kitten (Gatitos)', 'excellent-cat-kitten', 'Nutrición completa para gatitos en sus primeros 12 meses. Promueve el desarrollo muscular y la absorción de nutrientes esenciales.', 'gato', 'cachorro', 'todas', 'Cachorro', 'https://http2.mlstatic.com/D_NQ_NP_907577-MLA46675043690_072021-O.webp', FALSE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (161, 1, 3, 'Eukanuba Dog Light (Control de Peso)', 'eukanuba-dog-light', 'Nutrición Super Premium con L-carnitina y menos grasa para ayudar a perros con tendencia al sobrepeso a recuperar su masa magra.', 'perro', 'light', 'todas', 'Control Peso', 'https://http2.mlstatic.com/D_NQ_NP_832243-MLA99340263690_112025-F.jpg', FALSE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (162, 1, 3, 'Eukanuba Dog Senior', 'eukanuba-dog-senior', 'Nutrición adaptada para perros mayores (7+ años) con condroitina, glucosamina y antioxidantes para un envejecimiento activo y saludable.', 'perro', 'senior', 'todas', 'Senior', 'https://http2.mlstatic.com/D_NQ_NP_832243-MLA99340263690_112025-F.jpg', FALSE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (163, 2, 3, 'Eukanuba Gato Adulto', 'eukanuba-gato-adulto', 'Nueva línea felina Super Premium de Eukanuba. Proteína animal de alta calidad con pulpa de remolacha y salud digestiva superior.', 'gato', 'adulto', 'todas', 'Nuevo', 'https://http2.mlstatic.com/D_NQ_NP_667232-MLA51368945413_092022-O.webp', TRUE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (164, 2, 3, 'Eukanuba Gato Kitten', 'eukanuba-gato-kitten', 'Nutrición de alta densidad para gatitos en crecimiento con omega-3 (DHA) para potenciar el desarrollo cognitivo y defensas fuertes.', 'gato', 'cachorro', 'todas', 'Nuevo', 'https://http2.mlstatic.com/D_NQ_NP_667232-MLA51368945413_092022-O.webp', FALSE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (165, 1, 16, 'Vital Can Balanced Perro Exclusive Cerdo / Natural Cordero', 'vital-can-balanced-cerdo-cordero', 'Fórmula monoproteica especial con carne de cerdo o cordero seleccionada. Ideal para perros con sensibilidades alimentarias digestivas.', 'perro', 'adulto', 'todas', 'Monoproteico', 'https://http2.mlstatic.com/D_NQ_NP_678554-MLA99451664162_112025-F.jpg', FALSE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (166, 1, 16, 'Vital Can Balanced Perro Control de Peso', 'vital-can-balanced-control-peso', 'Bajo en calorías y rico en fibras naturales saciantes para el descenso y mantenimiento del peso saludable en caninos.', 'perro', 'light', 'todas', 'Control Peso', 'https://http2.mlstatic.com/D_NQ_NP_678554-MLA99451664162_112025-F.jpg', FALSE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (167, 2, 16, 'Vital Cat Balanced Gato Adulto', 'vital-cat-balanced-gato-adulto', 'Nutrición integral para felinos adultos con taurina, control de bolas de pelo y pH urinario balanceado.', 'gato', 'adulto', 'todas', 'Premium', 'https://http2.mlstatic.com/D_NQ_NP_698202-MLA46675043689_072021-O.webp', FALSE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (168, 2, 16, 'Vital Can Complete Gato Adulto', 'vital-can-complete-gato-adulto', 'Línea clásica y confiable de Vital Can con proteínas seleccionadas para el bienestar general del gato de hogar.', 'gato', 'adulto', 'todas', 'Económico', 'https://http2.mlstatic.com/D_NQ_NP_698202-MLA46675043689_072021-O.webp', FALSE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (169, 2, 16, 'Vital Can Complete Gato Castrado', 'vital-can-complete-gato-castrado', 'Diseñado para prevenir el sobrepeso y cálculos urinarios tras la esterilización en gatos adultos.', 'gato', 'castrado', 'todas', 'Castrado', 'https://http2.mlstatic.com/D_NQ_NP_698202-MLA46675043689_072021-O.webp', FALSE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (170, 2, 16, 'Vital Can Complete Gato Kitten', 'vital-can-complete-gato-kitten', 'Croquetas de tamaño pequeño con nutrientes para apoyar la primera etapa de vida y lactancia de gatitos.', 'gato', 'cachorro', 'todas', 'Cachorro', 'https://http2.mlstatic.com/D_NQ_NP_698202-MLA46675043689_072021-O.webp', FALSE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (171, 1, 24, 'Raza Perro Cachorros', 'raza-perro-cachorros', 'Alimento balanceado con leche, calcio y fósforo que promueve el desarrollo sano de cachorros de todas las razas.', 'perro', 'cachorro', 'todas', 'Económico', 'https://http2.mlstatic.com/D_NQ_NP_817905-MLA99842229311_112025-O.webp', FALSE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (172, 2, 24, 'Raza Gato Adulto (Pescado / Pollo y Leche)', 'raza-gato-adulto', 'Croquetas crujientes en deliciosos sabores de pescado, pollo y leche con taurina para la salud ocular y cardíaca felina.', 'gato', 'adulto', 'todas', 'Económico', 'https://http2.mlstatic.com/D_NQ_NP_817905-MLA99842229311_112025-O.webp', FALSE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (173, 2, 24, 'Raza Gatitos', 'raza-gatitos', 'Alimento nutritivo de fácil masticación con proteínas seleccionadas para gatitos en su primer año de crecimiento.', 'gato', 'cachorro', 'todas', 'Cachorro', 'https://http2.mlstatic.com/D_NQ_NP_817905-MLA99842229311_112025-O.webp', FALSE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (174, 2, 24, 'Raza Gato Castrado', 'raza-gato-castrado', 'Fórmula balanceada con fibras y energía moderada para el cuidado de gatos castrados de todas las edades.', 'gato', 'castrado', 'todas', 'Castrado', 'https://http2.mlstatic.com/D_NQ_NP_817905-MLA99842229311_112025-O.webp', FALSE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (175, 2, 19, 'Tiernitos Gatos Adulto', 'tiernitos-gatos-adulto', 'Alimento sabroso con alta palatabilidad e ingredientes balanceados para la nutrición diaria de gatos adultos.', 'gato', 'adulto', 'todas', 'Económico', 'https://http2.mlstatic.com/D_NQ_NP_795475-MLA99878002573_112025-O.webp', FALSE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (176, 3, 19, 'Tiernitos Pouch Alimento Húmedo (Carne / Cordero / Pavita)', 'tiernitos-pouch-humedo', 'Sobres pouch de alimento húmedo premium cocido al vapor en trozos jugosos. Sabores surtidos: Carne, Cordero y Pavita.', 'perro', 'humedo', 'todas', 'Húmedo', 'https://http2.mlstatic.com/D_NQ_NP_795475-MLA99878002573_112025-O.webp', TRUE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (177, 1, 20, 'Rosco Perro Cachorro', 'rosco-perro-cachorro', 'Nutrición económica completa para cachorros. Gran aporte de energía y vitalidad para el desarrollo inicial.', 'perro', 'cachorro', 'todas', 'Económico', 'https://http2.mlstatic.com/D_NQ_NP_817905-MLA99842229311_112025-O.webp', FALSE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (178, 2, 20, 'Rosco Gato Adulto', 'rosco-gato-adulto', 'Alimento completo para gatos con mix de proteínas de pescado y cocktail cárnico. Excelente relación precio-calidad.', 'gato', 'adulto', 'todas', 'Económico', 'https://http2.mlstatic.com/D_NQ_NP_817905-MLA99842229311_112025-O.webp', FALSE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (179, 1, 21, 'Pacha Perro Cachorro Cocktail', 'pacha-perro-cachorro-cocktail', 'Alimento balanceado clásico para cachorros. Rico sabor cárnico en bolsa cerrada y presentación fraccionada.', 'perro', 'cachorro', 'todas', 'Económico', 'https://http2.mlstatic.com/D_NQ_NP_817905-MLA99842229311_112025-O.webp', FALSE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (180, 2, 21, 'Pacha Gato Adulto', 'pacha-gato-adulto', 'Alimento económico para gatos adultos con variedad de opciones: Pescado, Cocktail y bolsas fraccionadas de 1 kg.', 'gato', 'adulto', 'todas', 'Económico', 'https://http2.mlstatic.com/D_NQ_NP_817905-MLA99842229311_112025-O.webp', FALSE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (181, 5, 30, 'Shampoo Osspret Medicado', 'shampoo-osspret-medicado', 'Shampoo dermatológico antiséptico para el tratamiento de afecciones de la piel en caninos y felinos.', 'perro', 'higiene', 'todas', 'Dermatológico', 'https://http2.mlstatic.com/D_NQ_NP_706344-MLA111706358457_052026-O.webp', FALSE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;
INSERT INTO products (id, category_id, brand_id, name, slug, description, pet_type, subcat, breed_size, badge, image_url, is_featured, is_promo, promo_tag, active)
VALUES (182, 5, 30, 'Shampoo Osspret Mix Frutal', 'shampoo-osspret-mix-frutal', 'Shampoo cosmético de uso frecuente con extractos frutales acondicionadores. Brillo, desenredo y fragancia duradera.', 'perro', 'higiene', 'todas', 'Belleza', 'https://http2.mlstatic.com/D_NQ_NP_777998-MLA100083527255_122025-O.webp', FALSE, FALSE, '', TRUE)
ON CONFLICT (id) DO UPDATE SET 
    name = EXCLUDED.name, description = EXCLUDED.description, image_url = EXCLUDED.image_url, badge = EXCLUDED.badge;

-- 2. Limpiar variantes anteriores de estos 38 productos (si existieran)
DELETE FROM product_variants WHERE product_id IN (145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182);

-- 3. Insertar las 50 Presentaciones con costos, márgenes y precios de venta
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (145, 'Bolsa 1,5 kg', 1.5, 30100.0, 25.0, 37625, 37625, 100, 'RC-KIT-1.5', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (145, 'Bolsa 7,5 kg', 7.5, 110650.0, 20.0, 132780, 132780, 100, 'RC-KIT-7.5', FALSE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (146, 'Bolsa 1,5 kg', 1.5, 30750.0, 25.0, 38438, 38438, 100, 'RC-URCARE-1.5', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (146, 'Bolsa 7,5 kg', 7.5, 127330.0, 20.0, 152796, 152796, 100, 'RC-URCARE-7.5', FALSE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (147, 'Bolsa 15 kg', 15.0, 120200.0, 18.0, 141836, 141836, 100, 'RC-GIANT-AD-15', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (148, 'Bolsa 15 kg', 15.0, 134700.0, 18.0, 158946, 158946, 100, 'RC-GIANT-JR-15', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (149, 'Bolsa 1,5 kg', 1.5, 20900.0, 25.0, 26125, 26125, 100, 'RC-VET-SAT-1.5', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (150, 'Bolsa 1,5 kg', 1.5, 22250.0, 25.0, 27812, 27812, 100, 'RC-VET-HEP-1.5', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (150, 'Bolsa 10 kg', 10.0, 120000.0, 18.0, 141600, 141600, 100, 'RC-VET-HEP-10', FALSE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (151, 'Bolsa 10 kg', 10.0, 125200.0, 18.0, 147736, 147736, 100, 'RC-VET-DIAB-10', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (152, 'Bolsa 1 kg', 1.0, 17970.0, 25.0, 22462, 22462, 100, 'PP-CAT-KIT-1', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (153, 'Bolsa 1 kg', 1.0, 19000.0, 25.0, 23750, 23750, 100, 'PP-CAT-LIGHT-1', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (154, 'Bolsa 15 kg', 15.0, 70820.0, 20.0, 84984, 84984, 100, 'EXC-PUP-15', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (154, 'Bolsa 20 kg', 20.0, 86480.0, 18.0, 102046, 102046, 100, 'EXC-PUP-20', FALSE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (155, 'Bolsa 20 kg', 20.0, 58100.0, 20.0, 69720, 69720, 100, 'EXC-MANT-AD-20', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (156, 'Bolsa 20 kg', 20.0, 63050.0, 20.0, 75660, 75660, 100, 'EXC-MANT-PUP-20', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (157, 'Bolsa 7,5 kg', 7.5, 66700.0, 22.0, 81374, 81374, 100, 'EXC-CAT-URI-7.5', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (157, 'Bolsa 15 kg', 15.0, 129300.0, 18.0, 152574, 152574, 100, 'EXC-CAT-URI-15', FALSE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (158, 'Bolsa 15 kg', 15.0, 82220.0, 18.0, 97020, 97020, 100, 'EXC-CAT-MANT-15', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (159, 'Bolsa 7,5 kg', 7.5, 66800.0, 22.0, 81496, 81496, 100, 'EXC-CAT-STER-7.5', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (160, 'Bolsa 1 kg', 1.0, 11400.0, 25.0, 14250, 14250, 100, 'EXC-CAT-KIT-1', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (160, 'Bolsa 7,5 kg', 7.5, 64220.0, 22.0, 78348, 78348, 100, 'EXC-CAT-KIT-7.5', FALSE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (161, 'Bolsa 3 kg', 3.0, 23100.0, 25.0, 28875, 28875, 100, 'EUK-LIGHT-3', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (161, 'Bolsa 15 kg', 15.0, 90500.0, 18.0, 106790, 106790, 100, 'EUK-LIGHT-15', FALSE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (162, 'Bolsa 15 kg', 15.0, 84400.0, 18.0, 99592, 99592, 100, 'EUK-SENIOR-15', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (163, 'Bolsa 7,5 kg', 7.5, 64900.0, 22.0, 79178, 79178, 100, 'EUK-CAT-AD-7.5', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (164, 'Bolsa 7,5 kg', 7.5, 68000.0, 22.0, 82960, 82960, 100, 'EUK-CAT-KIT-7.5', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (165, 'Bolsa 15 kg', 15.0, 62400.0, 20.0, 74880, 74880, 100, 'VC-BAL-CERD-15', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (166, 'Bolsa 20 kg', 20.0, 79800.0, 18.0, 94164, 94164, 100, 'VC-BAL-PESO-20', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (167, 'Bolsa 7,5 kg', 7.5, 49900.0, 22.0, 60878, 60878, 100, 'VC-BAL-GAT-7.5', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (168, 'Bolsa 15 kg', 15.0, 60900.0, 20.0, 73080, 73080, 100, 'VC-COMP-GAT-15', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (169, 'Bolsa 7,5 kg', 7.5, 38000.0, 22.0, 46360, 46360, 100, 'VC-COMP-CAST-7.5', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (170, 'Bolsa 7,5 kg', 7.5, 37100.0, 22.0, 45262, 45262, 100, 'VC-COMP-KIT-7.5', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (171, 'Bolsa 15 kg', 15.0, 27200.0, 20.0, 32640, 32640, 100, 'RAZA-PUP-15', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (172, 'Bolsa 10 kg (Pescado/Pollo y Leche)', 10.0, 24800.0, 22.0, 30256, 30256, 100, 'RAZA-GAT-10', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (172, 'Bolsa 15 kg (Pescado)', 15.0, 35400.0, 20.0, 42480, 42480, 100, 'RAZA-GAT-15', FALSE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (173, 'Bolsa 8 kg', 8.0, 23300.0, 22.0, 28426, 28426, 100, 'RAZA-KIT-8', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (174, 'Bolsa 10 kg', 10.0, 29750.0, 22.0, 36295, 36295, 100, 'RAZA-GAT-CAST-10', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (175, 'Bolsa 10 kg', 10.0, 27800.0, 22.0, 33916, 33916, 100, 'TIER-GAT-10', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (176, 'Sobre 100+20 gr (120 g)', 0.12, 900.0, 30.0, 1170, 1170, 100, 'TIER-POUCH-120', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (177, 'Bolsa 15 kg', 15.0, 25000.0, 20.0, 30000, 30000, 100, 'ROSCO-CACH-15', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (178, 'Bolsa 10 kg (Pescado)', 10.0, 20200.0, 22.0, 24644, 24644, 100, 'ROSCO-GAT-PESC-10', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (178, 'Bolsa 10 kg (Cocktail)', 10.0, 20800.0, 22.0, 25376, 25376, 100, 'ROSCO-GAT-COCK-10', FALSE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (179, 'Bolsa 10 kg', 10.0, 15300.0, 22.0, 18666, 18666, 100, 'PACHA-CACH-10', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (179, 'Fraccionado 3 kg', 3.0, 6000.0, 25.0, 7500, 7500, 100, 'PACHA-CACH-3', FALSE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (180, 'Bolsa 10 kg (Pescado)', 10.0, 20400.0, 22.0, 24888, 24888, 100, 'PACHA-GAT-PESC-10', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (180, 'Bolsa 10 kg (Cocktail)', 10.0, 22600.0, 22.0, 27572, 27572, 100, 'PACHA-GAT-COCK-10', FALSE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (180, 'Fraccionado 1 kg (Pescado)', 1.0, 3200.0, 25.0, 4000, 4000, 100, 'PACHA-GAT-FRAC-1', FALSE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (181, 'Botella 250 ml', 0.3, 7600.0, 25.0, 9500, 9500, 100, 'OSSP-MED-250', TRUE);
INSERT INTO product_variants (product_id, presentation_name, weight_kg, cost_price, margin_percent, sale_price, list_price, stock_qty, sku, is_default)
VALUES (182, 'Botella 250 ml', 0.3, 7600.0, 25.0, 9500, 9500, 100, 'OSSP-FRUT-250', TRUE);

-- Actualizar secuencia de autoincremento
SELECT setval('product_variants_id_seq', (SELECT MAX(id) FROM product_variants));